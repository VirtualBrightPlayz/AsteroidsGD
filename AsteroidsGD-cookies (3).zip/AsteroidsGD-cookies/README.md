# AsteroidsGD
!!!GODOT LICENSE!!!
https://github.com/godotengine/godot/blob/master/LICENSE.txt

!!!PRESS START 2P FONT LICENSE!!!
https://fonts.google.com/specimen/Press+Start+2P
This Font Software is licensed under the SIL Open Font License, Version 1.1. http://scripts.sil.org/OFL
# Disclaimer
I do not own Asteroids by Atari Inc. (there is good reason as to why this is free) I do not collect any information from this program.
